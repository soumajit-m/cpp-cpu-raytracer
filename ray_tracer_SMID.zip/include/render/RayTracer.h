#pragma once
#include "core/Ray.h"
#include "scene/BVH.h"
#include "scene/Material.h"

struct RayTraceResult
{
    bool hit = false;
    float distance = 1e30f;
    Vec3 normal;
    Material material;
};

class RayTracer
{
public:
    RayTraceResult trace(const Ray& ray, const BVH& bvh, bool smoothShading) const;
    bool traceShadow(const Ray& ray, const BVH& bvh, float maxDistance) const;

private:
    void intersectBVH(const Ray& ray, int nodeIdx, const BVH& bvh, RayTraceResult& bestResult) const;
    bool intersectBVHShadow(const Ray& ray, int nodeIdx, const BVH& bvh, float maxDistance) const;
};