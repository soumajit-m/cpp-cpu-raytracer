#pragma once
#include <immintrin.h>

struct Vec8f
{
    __m256 x;
    __m256 y;
    __m256 z;

    Vec8f()
    {
        x = _mm256_setzero_ps();
        y = _mm256_setzero_ps();
        z = _mm256_setzero_ps();
    }

    Vec8f(__m256 x, __m256 y, __m256 z) : x(x), y(y), z(z) {}

    // Broadcast constructor: loads the same (vx, vy, vz) into all 8 lanes
    Vec8f(float vx, float vy, float vz)
    {
        x = _mm256_set1_ps(vx);
        y = _mm256_set1_ps(vy);
        z = _mm256_set1_ps(vz);
    }

    Vec8f operator+(const Vec8f& b) const
    {
        return Vec8f(_mm256_add_ps(x, b.x), _mm256_add_ps(y, b.y), _mm256_add_ps(z, b.z));
    }

    Vec8f operator-(const Vec8f& b) const
    {
        return Vec8f(_mm256_sub_ps(x, b.x), _mm256_sub_ps(y, b.y), _mm256_sub_ps(z, b.z));
    }

    __m256 dot(const Vec8f& b) const
    {
        __m256 px = _mm256_mul_ps(x, b.x);
        __m256 py = _mm256_mul_ps(y, b.y);
        __m256 pz = _mm256_mul_ps(z, b.z);
        return _mm256_add_ps(_mm256_add_ps(px, py), pz);
    }

    Vec8f cross(const Vec8f& b) const
    {
        return Vec8f(
            _mm256_sub_ps(_mm256_mul_ps(y, b.z), _mm256_mul_ps(z, b.y)),
            _mm256_sub_ps(_mm256_mul_ps(z, b.x), _mm256_mul_ps(x, b.z)),
            _mm256_sub_ps(_mm256_mul_ps(x, b.y), _mm256_mul_ps(y, b.x))
        );
    }
};