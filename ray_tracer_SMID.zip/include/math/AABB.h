#pragma once
#include "math/Vec3.h"
#include "core/Ray.h"
#include <algorithm>

struct AABB
{
    Vec3 min;
    Vec3 max;

    // Default constructor
    AABB() : min(Vec3(1e30f, 1e30f, 1e30f)), max(Vec3(-1e30f, -1e30f, -1e30f)) {}

    // NEW: Two-argument constructor for the BVH builder
    AABB(const Vec3& minBounds, const Vec3& maxBounds) : min(minBounds), max(maxBounds) {}

    // Existing intersection logic...
    bool intersect(const Ray& ray, float& tHit) const
    {
        float tmin = (min.x - ray.origin.x) * ray.invDirection.x;
        float tmax = (max.x - ray.origin.x) * ray.invDirection.x;
        if (tmin > tmax) std::swap(tmin, tmax);

        float tymin = (min.y - ray.origin.y) * ray.invDirection.y;
        float tymax = (max.y - ray.origin.y) * ray.invDirection.y;
        if (tymin > tymax) std::swap(tymin, tymax);

        if ((tmin > tymax) || (tymin > tmax)) return false;
        if (tymin > tmin) tmin = tymin;
        if (tymax < tmax) tmax = tymax;

        float tzmin = (min.z - ray.origin.z) * ray.invDirection.z;
        float tzmax = (max.z - ray.origin.z) * ray.invDirection.z;
        if (tzmin > tzmax) std::swap(tzmin, tzmax);

        if ((tmin > tzmax) || (tzmin > tmax)) return false;
        if (tzmin > tmin) tmin = tzmin;
        if (tzmax < tmax) tmax = tzmax;

        tHit = tmin;
        if (tHit < 0.0f) tHit = tmax;
        return tHit >= 0.0f;
    }
};