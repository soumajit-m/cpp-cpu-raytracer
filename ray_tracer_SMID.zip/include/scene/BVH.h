#pragma once
#include <vector>
#include "math/AABB.h"
#include "scene/Triangle.h"
#include "scene/TriangleBatch.h"

struct BVHNode
{
    AABB bounds;
    int leftFirst;   // Leaf: index into batches array. Interior node: index to left child node.
    int batchCount;  // If > 0: Leaf node holding batchCount batches. If == 0: Interior node.

    bool isLeaf() const { return batchCount > 0; }
};

class BVH
{
public:
    BVH() = default;
    explicit BVH(std::vector<Triangle>& triangles);

    const std::vector<BVHNode>& getNodes() const { return nodes; }
    const std::vector<TriangleBatch>& getBatches() const { return batches; }

private:
    std::vector<BVHNode> nodes;
    std::vector<TriangleBatch> batches;

    void subdivide(int nodeIdx, std::vector<Triangle>& triangles, int firstTri, int triCount);
    void updateNodeBounds(int nodeIdx, const std::vector<Triangle>& triangles, int firstTri, int triCount);
};