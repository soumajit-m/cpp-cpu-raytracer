#pragma once
#include <immintrin.h>
#include "math/Vec8f.h"
#include "math/Vec3.h"
#include "scene/Material.h"

struct TriangleBatch
{
    Vec8f v0;
    Vec8f v1;
    Vec8f v2;

    Vec3 normals[8];
    Material materials[8];
    int count = 0; // Number of active triangles in this batch (1 to 8)
};