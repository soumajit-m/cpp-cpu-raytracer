#include "render/RayTracer.h"
#include <limits>
#include <immintrin.h>

RayTraceResult RayTracer::trace(const Ray& ray, const BVH& bvh, bool /*smoothShading*/) const
{
    RayTraceResult bestResult;
    bestResult.hit = false;
    bestResult.distance = std::numeric_limits<float>::max();

    if (bvh.getNodes().empty()) return bestResult;

    intersectBVH(ray, 0, bvh, bestResult);
    return bestResult;
}

bool RayTracer::traceShadow(const Ray& ray, const BVH& bvh, float maxDistance) const
{
    if (bvh.getNodes().empty()) return false;
    return intersectBVHShadow(ray, 0, bvh, maxDistance);
}

void RayTracer::intersectBVH(const Ray& ray, int nodeIdx, const BVH& bvh, RayTraceResult& bestResult) const
{
    const BVHNode& node = bvh.getNodes()[nodeIdx];
    float tBox;
    if (!node.bounds.intersect(ray, tBox) || tBox >= bestResult.distance) return;

    if (node.isLeaf())
    {
        Vec8f rOrig(ray.origin.x, ray.origin.y, ray.origin.z);
        Vec8f rDir(ray.direction.x, ray.direction.y, ray.direction.z);

        __m256 one = _mm256_set1_ps(1.0f);
        __m256 zero = _mm256_setzero_ps();
        __m256 eps = _mm256_set1_ps(1e-7f);
        __m256 minT = _mm256_set1_ps(0.001f);

        for (int b = 0; b < node.batchCount; ++b)
        {
            const TriangleBatch& batch = bvh.getBatches()[node.leftFirst + b];

            Vec8f edge1 = batch.v1 - batch.v0;
            Vec8f edge2 = batch.v2 - batch.v0;
            Vec8f h = rDir.cross(edge2);
            __m256 a = edge1.dot(h);

            // Parallel det check: |a| > 1e-7
            __m256 absA = _mm256_andnot_ps(_mm256_set1_ps(-0.0f), a);
            __m256 detMask = _mm256_cmp_ps(absA, eps, _CMP_GT_OQ);

            __m256 f = _mm256_div_ps(one, a);
            Vec8f s = rOrig - batch.v0;
            __m256 u = _mm256_mul_ps(f, s.dot(h));

            __m256 uValid = _mm256_and_ps(_mm256_cmp_ps(u, zero, _CMP_GE_OQ), _mm256_cmp_ps(u, one, _CMP_LE_OQ));

            Vec8f q = s.cross(edge1);
            __m256 v = _mm256_mul_ps(f, rDir.dot(q));
            __m256 uvSum = _mm256_add_ps(u, v);

            __m256 vValid = _mm256_and_ps(_mm256_cmp_ps(v, zero, _CMP_GE_OQ), _mm256_cmp_ps(uvSum, one, _CMP_LE_OQ));

            __m256 t = _mm256_mul_ps(f, edge2.dot(q));
            __m256 maxDistVec = _mm256_set1_ps(bestResult.distance);

            __m256 tValid = _mm256_and_ps(_mm256_cmp_ps(t, minT, _CMP_GT_OQ), _mm256_cmp_ps(t, maxDistVec, _CMP_LT_OQ));

            __m256 hitMask = _mm256_and_ps(detMask, _mm256_and_ps(uValid, _mm256_and_ps(vValid, tValid)));

            int mask = _mm256_movemask_ps(hitMask);

            if (mask != 0)
            {
                alignas(32) float tValues[8];
                _mm256_store_ps(tValues, t);

                for (int i = 0; i < batch.count; ++i)
                {
                    if ((mask & (1 << i)) && tValues[i] < bestResult.distance)
                    {
                        bestResult.hit = true;
                        bestResult.distance = tValues[i];
                        bestResult.normal = batch.normals[i];
                        bestResult.material = batch.materials[i];

                        if (bestResult.normal.dot(ray.direction) > 0.0f)
                        {
                            bestResult.normal = bestResult.normal * -1.0f;
                        }
                    }
                }
            }
        }
    }
    else
    {
        intersectBVH(ray, node.leftFirst, bvh, bestResult);
        intersectBVH(ray, node.leftFirst + 1, bvh, bestResult);
    }
}

bool RayTracer::intersectBVHShadow(const Ray& ray, int nodeIdx, const BVH& bvh, float maxDistance) const
{
    const BVHNode& node = bvh.getNodes()[nodeIdx];
    float tBox;
    if (!node.bounds.intersect(ray, tBox) || tBox >= maxDistance) return false;

    if (node.isLeaf())
    {
        Vec8f rOrig(ray.origin.x, ray.origin.y, ray.origin.z);
        Vec8f rDir(ray.direction.x, ray.direction.y, ray.direction.z);

        __m256 one = _mm256_set1_ps(1.0f);
        __m256 zero = _mm256_setzero_ps();
        __m256 eps = _mm256_set1_ps(1e-7f);
        __m256 minT = _mm256_set1_ps(0.001f);
        __m256 maxD = _mm256_set1_ps(maxDistance);

        for (int b = 0; b < node.batchCount; ++b)
        {
            const TriangleBatch& batch = bvh.getBatches()[node.leftFirst + b];

            Vec8f edge1 = batch.v1 - batch.v0;
            Vec8f edge2 = batch.v2 - batch.v0;
            Vec8f h = rDir.cross(edge2);
            __m256 a = edge1.dot(h);

            __m256 absA = _mm256_andnot_ps(_mm256_set1_ps(-0.0f), a);
            __m256 detMask = _mm256_cmp_ps(absA, eps, _CMP_GT_OQ);

            __m256 f = _mm256_div_ps(one, a);
            Vec8f s = rOrig - batch.v0;
            __m256 u = _mm256_mul_ps(f, s.dot(h));

            __m256 uValid = _mm256_and_ps(_mm256_cmp_ps(u, zero, _CMP_GE_OQ), _mm256_cmp_ps(u, one, _CMP_LE_OQ));

            Vec8f q = s.cross(edge1);
            __m256 v = _mm256_mul_ps(f, rDir.dot(q));
            __m256 uvSum = _mm256_add_ps(u, v);

            __m256 vValid = _mm256_and_ps(_mm256_cmp_ps(v, zero, _CMP_GE_OQ), _mm256_cmp_ps(uvSum, one, _CMP_LE_OQ));

            __m256 t = _mm256_mul_ps(f, edge2.dot(q));
            __m256 tValid = _mm256_and_ps(_mm256_cmp_ps(t, minT, _CMP_GT_OQ), _mm256_cmp_ps(t, maxD, _CMP_LT_OQ));

            __m256 hitMask = _mm256_and_ps(detMask, _mm256_and_ps(uValid, _mm256_and_ps(vValid, tValid)));

            int mask = _mm256_movemask_ps(hitMask);

            // Filter out lanes beyond the batch's valid triangle count
            int activeMask = mask & ((1 << batch.count) - 1);
            if (activeMask != 0)
            {
                return true; // Instant early exit on occluder detection
            }
        }
        return false;
    }

    if (intersectBVHShadow(ray, node.leftFirst, bvh, maxDistance)) return true;
    return intersectBVHShadow(ray, node.leftFirst + 1, bvh, maxDistance);
}