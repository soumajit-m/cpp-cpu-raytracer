#include "scene/BVH.h"
#include <algorithm>

BVH::BVH(std::vector<Triangle>& triangles)
{
    if (triangles.empty()) return;

    nodes.reserve(triangles.size() * 2);

    BVHNode root;
    root.leftFirst = 0;
    root.batchCount = 0;
    nodes.push_back(root);

    updateNodeBounds(0, triangles, 0, static_cast<int>(triangles.size()));
    subdivide(0, triangles, 0, static_cast<int>(triangles.size()));
}

void BVH::updateNodeBounds(int nodeIdx, const std::vector<Triangle>& triangles, int firstTri, int triCount)
{
    Vec3 minBound(1e30f, 1e30f, 1e30f);
    Vec3 maxBound(-1e30f, -1e30f, -1e30f);

    for (int i = 0; i < triCount; ++i)
    {
        const Triangle& tri = triangles[firstTri + i];
        minBound = Vec3::min(minBound, Vec3::min(tri.v0, Vec3::min(tri.v1, tri.v2)));
        maxBound = Vec3::max(maxBound, Vec3::max(tri.v0, Vec3::max(tri.v1, tri.v2)));
    }

    nodes[nodeIdx].bounds = AABB(minBound, maxBound);
}

void BVH::subdivide(int nodeIdx, std::vector<Triangle>& triangles, int firstTri, int triCount)
{
    // If 8 or fewer triangles remain, pack into a leaf batch
    if (triCount <= 8)
    {
        int startBatchIdx = static_cast<int>(batches.size());

        TriangleBatch batch;
        batch.count = triCount;

        alignas(32) float v0x[8] = { 0 }, v0y[8] = { 0 }, v0z[8] = { 0 };
        alignas(32) float v1x[8] = { 0 }, v1y[8] = { 0 }, v1z[8] = { 0 };
        alignas(32) float v2x[8] = { 0 }, v2y[8] = { 0 }, v2z[8] = { 0 };

        for (int i = 0; i < triCount; ++i)
        {
            const Triangle& tri = triangles[firstTri + i];
            v0x[i] = tri.v0.x; v0y[i] = tri.v0.y; v0z[i] = tri.v0.z;
            v1x[i] = tri.v1.x; v1y[i] = tri.v1.y; v1z[i] = tri.v1.z;
            v2x[i] = tri.v2.x; v2y[i] = tri.v2.y; v2z[i] = tri.v2.z;

            batch.normals[i] = (tri.n0 + tri.n1 + tri.n2) * (1.0f / 3.0f);
            if (batch.normals[i].lengthSq() < 1e-6f)
            {
                batch.normals[i] = (tri.v1 - tri.v0).cross(tri.v2 - tri.v0).normalized();
            }
            batch.materials[i] = tri.material;
        }

        batch.v0 = Vec8f(_mm256_load_ps(v0x), _mm256_load_ps(v0y), _mm256_load_ps(v0z));
        batch.v1 = Vec8f(_mm256_load_ps(v1x), _mm256_load_ps(v1y), _mm256_load_ps(v1z));
        batch.v2 = Vec8f(_mm256_load_ps(v2x), _mm256_load_ps(v2y), _mm256_load_ps(v2z));

        batches.push_back(batch);

        nodes[nodeIdx].leftFirst = startBatchIdx;
        nodes[nodeIdx].batchCount = 1;
        return;
    }

    // Split along the longest extent axis
    Vec3 extent = nodes[nodeIdx].bounds.max - nodes[nodeIdx].bounds.min;
    int axis = 0;
    if (extent.y > extent.x) axis = 1;
    if (extent.z > (axis == 1 ? extent.y : extent.x)) axis = 2;

    float splitPos = nodes[nodeIdx].bounds.min[axis] + extent[axis] * 0.5f;

    int i = firstTri;
    int j = firstTri + triCount - 1;

    while (i <= j)
    {
        float centroid = (triangles[i].v0[axis] + triangles[i].v1[axis] + triangles[i].v2[axis]) / 3.0f;
        if (centroid < splitPos)
        {
            i++;
        }
        else
        {
            std::swap(triangles[i], triangles[j]);
            j--;
        }
    }

    int leftCount = i - firstTri;
    if (leftCount == 0 || leftCount == triCount)
    {
        leftCount = triCount / 2;
    }

    int leftChildIdx = static_cast<int>(nodes.size());
    nodes.emplace_back();
    nodes.emplace_back();

    nodes[nodeIdx].leftFirst = leftChildIdx;
    nodes[nodeIdx].batchCount = 0; // Interior node

    updateNodeBounds(leftChildIdx, triangles, firstTri, leftCount);
    updateNodeBounds(leftChildIdx + 1, triangles, firstTri + leftCount, triCount - leftCount);

    subdivide(leftChildIdx, triangles, firstTri, leftCount);
    subdivide(leftChildIdx + 1, triangles, firstTri + leftCount, triCount - leftCount);
}