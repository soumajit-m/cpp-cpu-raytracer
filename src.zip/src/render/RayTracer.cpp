#include "render/RayTracer.h"
#include <limits>

RayTraceResult RayTracer::trace(const Ray& ray, const BVH& bvh, bool smoothShading) const
{
    RayTraceResult bestResult;
    bestResult.hit = false;
    bestResult.distance = std::numeric_limits<float>::max();

    if (bvh.getNodes().empty()) return bestResult;

    intersectBVH(ray, 0, bvh, bestResult, smoothShading);

    return bestResult;
}

void RayTracer::intersectBVH(const Ray& ray, int nodeIdx, const BVH& bvh, RayTraceResult& bestResult, bool smoothShading) const
{
    const BVHNode& node = bvh.getNodes()[nodeIdx];
    float tHit;
    
    // 1. Ray misses the box entirely
    if (!node.bounds.intersect(ray, tHit)) return;
    
    // 2. We already hit a triangle that is closer than this bounding box
    if (tHit >= bestResult.distance) return;

    if (node.isLeaf())
    {
        constexpr float EPSILON = 0.000001f;

        for (int i = 0; i < node.triCount; ++i)
        {
            const Triangle& tri = bvh.getTriangles()[node.leftFirst + i];

            Vec3 edge1 = tri.v1 - tri.v0;
            Vec3 edge2 = tri.v2 - tri.v0;
            Vec3 h = ray.direction.cross(edge2);
            float a = edge1.dot(h);

            if (a > -EPSILON && a < EPSILON) continue;

            float f = 1.0f / a;
            Vec3 s = ray.origin - tri.v0;
            float u = f * s.dot(h);
            if (u < 0.0f || u > 1.0f) continue;

            Vec3 q = s.cross(edge1);
            float v = f * ray.direction.dot(q);
            if (v < 0.0f || u + v > 1.0f) continue;

            float t = f * edge2.dot(q);
            
            if (t > EPSILON && t < bestResult.distance)
            {
                bestResult.hit = true;
                bestResult.distance = t;

                Vec3 normal;
                if (smoothShading)
                {
                    // Barycentric interpolation using the vertex normals
                    float w = 1.0f - u - v;
                    normal = (tri.n0 * w + tri.n1 * u + tri.n2 * v).normalized();
                }
                else
                {
                    // Classic flat face normal
                    normal = edge1.cross(edge2).normalized();
                }

                if (normal.dot(ray.direction) > 0.0f)
                {
                    normal = normal * -1.0f;
                }
                bestResult.normal = normal;
            }
        }
    }
    else
    {
        // Traverse left and right children
        intersectBVH(ray, node.leftFirst, bvh, bestResult, smoothShading);
        intersectBVH(ray, node.leftFirst + 1, bvh, bestResult, smoothShading);
    }
}
