#include "render/Renderer.h"
#include "render/RayGenerator.h"

#include <algorithm>
#include <cmath>
#include <cstdint>

Renderer::Renderer(int width, int height)
    : width(width),
    height(height),
    pixels(static_cast<std::size_t>(width)* static_cast<std::size_t>(height)),
    stopPool(false),
    activeTiles(0),
    currentCamera(nullptr),
    currentBVH(nullptr)
{
    unsigned int hardwareThreads = std::thread::hardware_concurrency();
    if (hardwareThreads == 0)
    {
        hardwareThreads = 4;
    }

    // Spin up the threads exactly once when the program launches
    for (unsigned int i = 0; i < hardwareThreads; ++i)
    {
        threads.emplace_back(&Renderer::workerLoop, this);
    }
}

Renderer::~Renderer()
{
    // Lock the queue, tell threads to stop, and wake them all up
    {
        std::unique_lock<std::mutex> lock(queueMutex);
        stopPool = true;
    }
    condition.notify_all();

    // Wait for all threads to finish their current loop and join the main thread
    for (std::thread& thread : threads)
    {
        if (thread.joinable())
        {
            thread.join();
        }
    }
}

void Renderer::workerLoop()
{
    while (true)
    {
        Tile tile;

        // 1. Lock the mutex to check the queue safely
        {
            std::unique_lock<std::mutex> lock(queueMutex);

            // 2. Put the thread to sleep until a tile is available OR the pool is stopped
            condition.wait(lock, [this]() {
                return stopPool || !tileQueue.empty();
                });

            // 3. If the program is closing and no tiles are left, exit the loop
            if (stopPool && tileQueue.empty())
            {
                return;
            }

            // 4. Grab a tile and pop it off the queue
            tile = tileQueue.front();
            tileQueue.pop();
        } // The lock is automatically released here so other threads can grab tiles

        // 5. Do the heavy math outside the lock so cores run in parallel
        renderTile(*currentCamera, *currentBVH, tile.startX, tile.startY, tile.endX, tile.endY, currentLight);

        // 6. Decrement the atomic counter. If this was the last tile, wake up the main thread
        if (--activeTiles == 0)
        {
            renderComplete.notify_one();
        }
    }
}

void Renderer::renderPixel(
    const Camera& camera,
    const BVH& bvh,
    int x,
    int y,
    const Vec3& lightPosition
)
{
    Ray ray = RayGenerator::generate(camera, x, y, width, height);
    RayTraceResult result = rayTracer.trace(ray, bvh, smoothShadingEnabled);

    std::uint32_t color;

    if (result.hit)
    {
        Vec3 hitPoint = ray.at(result.distance);
        Vec3 normal = result.normal;

        Vec3 toLight = (lightPosition - hitPoint).normalized();
        float brightness = normal.dot(toLight);
        brightness = std::max(0.0f, brightness);

        int intensity = static_cast<int>(brightness * 255.0f);
        intensity = std::clamp(intensity, 0, 255);

        color =
            (static_cast<std::uint32_t>(intensity) << 24) |
            (static_cast<std::uint32_t>(intensity) << 16) |
            (static_cast<std::uint32_t>(intensity) << 8) |
            255u;
    }
    else
    {
        color = 0x2D2D2DFF; // Dark gray background
    }

    pixels[static_cast<std::size_t>(y) * static_cast<std::size_t>(width) + static_cast<std::size_t>(x)] = color;
}

void Renderer::renderTile(
    const Camera& camera,
    const BVH& bvh,
    int startX,
    int startY,
    int endX,
    int endY,
    const Vec3& lightPosition
)
{
    for (int y = startY; y < endY; ++y)
    {
        for (int x = startX; x < endX; ++x)
        {
            renderPixel(camera, bvh, x, y, lightPosition);
        }
    }
}

void Renderer::render(const Camera& camera, const BVH& bvh)
{
    // Update the pointers so the sleeping workers know what to render
    currentCamera = &camera;
    currentBVH = &bvh;
    currentLight = Vec3(3.0f, 4.0f, -2.0f);

    int tileCount = 0;

    // Lock the queue and push all the tiles for this specific frame
    {
        std::unique_lock<std::mutex> lock(queueMutex);

        for (int y = 0; y < height; y += TILE_SIZE)
        {
            for (int x = 0; x < width; x += TILE_SIZE)
            {
                tileQueue.push({
                    x, y,
                    std::min(x + TILE_SIZE, width),
                    std::min(y + TILE_SIZE, height)
                    });
                tileCount++;
            }
        }
        activeTiles = tileCount;
    }

    // Wake up all sleeping worker threads instantly
    condition.notify_all();

    // Put the main thread to sleep until the activeTiles counter hits 0
    {
        std::unique_lock<std::mutex> lock(queueMutex);
        renderComplete.wait(lock, [this]() {
            return activeTiles == 0;
            });
    }
}

const std::uint32_t* Renderer::getPixels() const
{
    return pixels.data();
}

int Renderer::getWidth() const
{
    return width;
}

int Renderer::getHeight() const
{
    return height;
}

void Renderer::toggleSmoothShading()
{
    smoothShadingEnabled = !smoothShadingEnabled;
}

bool Renderer::isSmoothShadingEnabled() const
{
    return smoothShadingEnabled;
}