#include <SDL3/SDL.h>
#include <SDL3_ttf/SDL_ttf.h>

#include <iostream>
#include <chrono>
#include <iomanip>
#include <cstdint>
#include <string>
#include <vector>

#include "core/Camera.h"
#include "scene/Sphere.h"
#include "scene/BVH.h"
#include "render/Renderer.h"

int main()
{
    constexpr int WINDOW_WIDTH = 1920;
    constexpr int WINDOW_HEIGHT = 1080;
    constexpr float MOVE_SPEED = 5.0f;
    constexpr float MOUSE_SENSITIVITY = 0.1f;
    constexpr int FONT_SIZE = 24;

    std::cout << "Starting renderer...\n";

    if (!SDL_Init(SDL_INIT_VIDEO))
    {
        std::cerr << "SDL_Init failed: " << SDL_GetError() << '\n';
        return 1;
    }

    if (!TTF_Init())
    {
        std::cerr << "TTF_Init failed: " << SDL_GetError() << '\n';
        SDL_Quit();
        return 1;
    }

    SDL_Window* window = SDL_CreateWindow("CPU Ray Tracer (BVH)", WINDOW_WIDTH, WINDOW_HEIGHT, 0);
    if (window == nullptr)
    {
        std::cerr << "SDL_CreateWindow failed: " << SDL_GetError() << '\n';
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    SDL_Renderer* sdlRenderer = SDL_CreateRenderer(window, nullptr);
    if (sdlRenderer == nullptr)
    {
        std::cerr << "SDL_CreateRenderer failed: " << SDL_GetError() << '\n';
        SDL_DestroyWindow(window);
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    SDL_Texture* texture = SDL_CreateTexture(
        sdlRenderer,
        SDL_PIXELFORMAT_RGBA8888,
        SDL_TEXTUREACCESS_STREAMING,
        WINDOW_WIDTH,
        WINDOW_HEIGHT
    );

    if (texture == nullptr)
    {
        std::cerr << "SDL_CreateTexture failed: " << SDL_GetError() << '\n';
        SDL_DestroyRenderer(sdlRenderer);
        SDL_DestroyWindow(window);
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    TTF_Font* font = TTF_OpenFont("assets/fonts/arial.ttf", FONT_SIZE);
    if (font == nullptr)
    {
        std::cerr << "TTF_OpenFont failed: " << SDL_GetError() << '\n';
        SDL_DestroyTexture(texture);
        SDL_DestroyRenderer(sdlRenderer);
        SDL_DestroyWindow(window);
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    if (!SDL_SetWindowRelativeMouseMode(window, true))
    {
        std::cerr << "Warning: Could not enable relative mouse mode: " << SDL_GetError() << '\n';
    }

    Camera camera;
    camera.setAspectRatio(static_cast<float>(WINDOW_WIDTH) / static_cast<float>(WINDOW_HEIGHT));

    Renderer renderer(WINDOW_WIDTH, WINDOW_HEIGHT);

    // =========================================================
    // SCENE: Build Mesh & BVH
    // =========================================================
    std::cout << "Generating mesh...\n";
    std::vector<Triangle> triangles = Sphere::generateMesh(Vec3(0.0f, 0.0f, -10.0f), 1.0f, 50, 50);
    
    std::cout << "Building BVH...\n";
    BVH sceneBVH(triangles);
    std::cout << "BVH Build complete.\n";

    using Clock = std::chrono::steady_clock;
    auto previousTime = Clock::now();
    double fpsTimer = 0.0;
    int frameCount = 0;
    double displayedFPS = 0.0;
    double displayedFrameTime = 0.0;
    bool running = true;

    while (running)
    {
        auto currentTime = Clock::now();
        std::chrono::duration<float> elapsed = currentTime - previousTime;
        previousTime = currentTime;
        float deltaTime = elapsed.count();
        if (deltaTime > 0.1f) deltaTime = 0.1f;

        SDL_Event event;
        while (SDL_PollEvent(&event))
        {
            if (event.type == SDL_EVENT_QUIT) running = false;
            if (event.type == SDL_EVENT_KEY_DOWN)
            {
                if (event.key.key == SDLK_ESCAPE) running = false;
                if (event.key.key == SDLK_M) renderer.toggleSmoothShading(); // Toggle Switch
            }
            if (event.type == SDL_EVENT_MOUSE_MOTION)
            {
                camera.rotate(event.motion.xrel * MOUSE_SENSITIVITY, -event.motion.yrel * MOUSE_SENSITIVITY);
            }
        }

        const bool* keyboard = SDL_GetKeyboardState(nullptr);
        float movement = MOVE_SPEED * deltaTime;
        if (keyboard[SDL_SCANCODE_W]) camera.moveForward(movement);
        if (keyboard[SDL_SCANCODE_S]) camera.moveForward(-movement);
        if (keyboard[SDL_SCANCODE_A]) camera.moveRight(-movement);
        if (keyboard[SDL_SCANCODE_D]) camera.moveRight(movement);
        if (keyboard[SDL_SCANCODE_SPACE]) camera.moveUp(movement);
        if (keyboard[SDL_SCANCODE_LCTRL]) camera.moveUp(-movement);

        auto renderStart = Clock::now();
        renderer.render(camera, sceneBVH);
        auto renderEnd = Clock::now();
        std::chrono::duration<double, std::milli> renderDuration = renderEnd - renderStart;

        SDL_UpdateTexture(
            texture, nullptr, renderer.getPixels(),
            renderer.getWidth() * static_cast<int>(sizeof(std::uint32_t))
        );

        SDL_SetRenderDrawColor(sdlRenderer, 0, 0, 0, 255);
        SDL_RenderClear(sdlRenderer);
        SDL_RenderTexture(sdlRenderer, texture, nullptr, nullptr);

        fpsTimer += elapsed.count();
        frameCount++;
        if (fpsTimer >= 1.0)
        {
            displayedFPS = static_cast<double>(frameCount) / fpsTimer;
            displayedFrameTime = 1000.0 / displayedFPS;
            fpsTimer = 0.0;
            frameCount = 0;
        }

        std::string fpsText = "FPS: " + std::to_string(displayedFPS);
        std::string frameText = "Frame: " + std::to_string(displayedFrameTime) + " ms";

        SDL_Surface* fpsSurface = TTF_RenderText_Blended(font, fpsText.c_str(), 0, SDL_Color{255, 255, 255, 255});
        if (fpsSurface != nullptr)
        {
            SDL_Texture* fpsTex = SDL_CreateTextureFromSurface(sdlRenderer, fpsSurface);
            if (fpsTex != nullptr)
            {
                SDL_FRect dest{10.0f, 10.0f, static_cast<float>(fpsSurface->w), static_cast<float>(fpsSurface->h)};
                SDL_RenderTexture(sdlRenderer, fpsTex, nullptr, &dest);
                SDL_DestroyTexture(fpsTex);
            }
            SDL_DestroySurface(fpsSurface);
        }

        SDL_Surface* frameSurface = TTF_RenderText_Blended(font, frameText.c_str(), 0, SDL_Color{255, 255, 255, 255});
        if (frameSurface != nullptr)
        {
            SDL_Texture* frameTex = SDL_CreateTextureFromSurface(sdlRenderer, frameSurface);
            if (frameTex != nullptr)
            {
                SDL_FRect dest{10.0f, 40.0f, static_cast<float>(frameSurface->w), static_cast<float>(frameSurface->h)};
                SDL_RenderTexture(sdlRenderer, frameTex, nullptr, &dest);
                SDL_DestroyTexture(frameTex);
            }
            SDL_DestroySurface(frameSurface);
        }

        SDL_RenderPresent(sdlRenderer);
    }

    std::cout << "Renderer shutting down...\n";
    SDL_SetWindowRelativeMouseMode(window, false);
    TTF_CloseFont(font);
    SDL_DestroyTexture(texture);
    SDL_DestroyRenderer(sdlRenderer);
    SDL_DestroyWindow(window);
    TTF_Quit();
    SDL_Quit();
    std::cout << "Renderer shut down successfully.\n";

    return 0;
}
