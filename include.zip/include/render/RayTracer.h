#pragma once

#include "core/Ray.h"
#include "scene/BVH.h"

struct RayTraceResult
{
    bool hit;
    float distance;
    Vec3 normal;
};

class RayTracer
{
public:
    RayTraceResult trace(const Ray& ray, const BVH& bvh, bool smoothShading) const;

private:
    void intersectBVH(const Ray& ray, int nodeIdx, const BVH& bvh, RayTraceResult& bestResult, bool smoothShading) const;
};
